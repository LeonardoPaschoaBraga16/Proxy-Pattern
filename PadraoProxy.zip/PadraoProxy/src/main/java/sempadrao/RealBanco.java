/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sempadrao;

import compadrao.*;

/**
 *
 * @author Leo
 */
public class RealBanco{
    private double saldo = 1500;
    private boolean login = false;
    
    public void login(String name) {
        System.out.println("Seja Bem vindo(a), " + name);
        this.login = true;
    }
    
    public void saldo(){
        if (login == true){
            System.out.println("O saldo atual é de " + saldo);
        } else {
            System.out.println("Faca o login primeiro");
        }
    }

    public void transferir(double valor) {
        if (login == true){
            saldo -= valor;
            System.out.println("Foram transferidos R$" + valor + " da sua conta");
        } else {
            System.out.println("Faca o login primeiro");
        }
    }

    public void receber(double valor) {
        if (login == true){
            saldo += valor;
            System.out.println("Você recebeu R$" + valor);
        } else {
            System.out.println("Faca o login primeiro");
        }
    }
    
}
