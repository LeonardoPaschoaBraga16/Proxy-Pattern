/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sempadrao;

import compadrao.*;

/**
 *
 * @author Leo
 */
public class PadraoProxy {

    public static void main(String[] args) {
        RealBanco b1 = new RealBanco();
        
        b1.saldo();
        
        b1.login("Leonardo");
        
        b1.saldo();
        b1.transferir(500);
        b1.receber(700);
        
        b1.saldo();
    }
}
