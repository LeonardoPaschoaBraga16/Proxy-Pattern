/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package compadrao;

/**
 *
 * @author Leo
 */
public class PadraoProxy {

    public static void main(String[] args) {
        ProxyBanco proxy = new ProxyBanco();
        
        proxy.saldo();
        
        proxy.login("Leonardo");
        
        proxy.saldo();
        proxy.transferir(500);
        proxy.receber(700);
        
        proxy.saldo();
    }
}
