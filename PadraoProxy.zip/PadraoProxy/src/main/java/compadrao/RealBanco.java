/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package compadrao;

/**
 *
 * @author Leo
 */
public class RealBanco implements BancoInterface{
    private double saldo = 1500;

    @Override
    public void login(String name) {
        System.out.println("Seja Bem vindo(a), " + name);
    }
    
    @Override
    public void saldo(){
        System.out.println("O saldo atual é de " + saldo);
    }

    @Override
    public void transferir(double valor) {
       saldo -= valor;
        System.out.println("Foram transferidos R$" + valor + " da sua conta");
    }

    @Override
    public void receber(double valor) {
       saldo += valor;
       System.out.println("Você recebeu R$" + valor);
    }
    
}
