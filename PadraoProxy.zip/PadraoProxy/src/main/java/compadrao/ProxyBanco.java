/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package compadrao;

/**
 *
 * @author Leo
 */
public class ProxyBanco implements BancoInterface{
    
    private RealBanco realBanco = new RealBanco();
    private boolean login = false;
    private double saldo = 1500;

    @Override
    public void login(String name) {
        System.out.println("Iniciando Proxy");
        realBanco.login(name);
        this.login = true;
    }
    
    @Override
    public void saldo(){
        if(login == true){
            realBanco.saldo();
        } else {
            System.out.println("Voce nao realizou o login, realize o login antes de ter acesso a demais funcoes");
        }
    }

    @Override
    public void transferir(double valor) {
       if(login == true){
            realBanco.transferir(valor);
        } else {
            System.out.println("Você não realizou o login, realize o login antes de ter acesso a demais funções");
        }
    }

    @Override
    public void receber(double valor) {
       if(login == true){
            realBanco.receber(valor);
        } else {
            System.out.println("Você não realizou o login, realize o login antes de ter acesso a demais funções");
        }
    }
    
}
